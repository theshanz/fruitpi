set(CMAKE_HOST_SYSTEM "Linux-7.1.5-arch1-1")
set(CMAKE_HOST_SYSTEM_NAME "Linux")
set(CMAKE_HOST_SYSTEM_VERSION "7.1.5-arch1-1")
set(CMAKE_HOST_SYSTEM_PROCESSOR "x86_64")

include("/home/theshan/Android/Sdk/ndk/28.2.13676358/build/cmake/android.toolchain.cmake")

set(CMAKE_SYSTEM "Android-1")
set(CMAKE_SYSTEM_NAME "Android")
set(CMAKE_SYSTEM_VERSION "1")
set(CMAKE_SYSTEM_PROCESSOR "i686")

set(CMAKE_CROSSCOMPILING "TRUE")

set(CMAKE_SYSTEM_LOADED 1)
